import {
    getSurfaceDefinition,
    isSurfaceStateAllowed,
} from "./SurfaceDefinition";

import {
    getSurfaceStateDefinition,
} from "./SurfaceStateDefinition";

import {
    SurfaceType,
} from "./SurfaceType";

import {
    SurfaceZone,
} from "./SurfaceZone";

import {
    SurfaceStateRegion,
} from "./SurfaceStateRegion";

import type {
    SurfaceZoneDefinition,
} from "./SurfaceZone";

import type {
    SurfaceStateRegionDefinition,
} from "./SurfaceStateRegion";

import type {
    SurfaceState,
} from "./SurfaceState";

import type {
    SurfaceSample,
} from "./SurfaceSample";

export type SurfaceChangeListener =
    () => void;

export type SurfaceDerivedStateResolver =
    (
        worldX: number,
        worldY: number,
        currentSample: SurfaceSample,
    ) => SurfaceState | null;

/**
 * Authoritative spatial surface-query and runtime-state system.
 *
 * Base terrain comes from authored SurfaceZones or the
 * course-wide fallback surface. Runtime SurfaceStateRegions
 * may then override only the state of the same base surface
 * type.
 *
 * Example:
 *
 * fallback Grass
 * + Scorched Grass state region
 * = Scorched Grass sample
 *
 * A Grass state region never converts Sand into Grass.
 */
export class SurfaceSystem {

    private readonly defaultSurfaceType:
        SurfaceType;

    private readonly zones:
        SurfaceZone[] = [];

    private readonly stateRegions:
        SurfaceStateRegion[] = [];

    private readonly changeListeners:
        Set<SurfaceChangeListener> =
        new Set<SurfaceChangeListener>();

    /**
     * Lightweight derived categorical state sources.
     *
     * Derived resolvers are consulted only after explicit SurfaceStateRegions
     * and explicitly changed authored zone states have had a chance to win.
     * This keeps systems such as moisture from stamping thousands of runtime
     * regions into SurfaceSystem.
     */
    private readonly derivedStateResolvers:
        Map<
            string,
            SurfaceDerivedStateResolver
        > =
        new Map<
            string,
            SurfaceDerivedStateResolver
        >();

    constructor(
        defaultSurfaceType:
            SurfaceType =
            SurfaceType.Grass,
    ) {

        this.defaultSurfaceType =
            defaultSurfaceType;

        const defaultSurface =
            getSurfaceDefinition(
                this.defaultSurfaceType,
            );

        this.validateStateForSurface(
            this.defaultSurfaceType,
            defaultSurface.defaultState,
        );
    }

    public update(
        deltaTime:
            number,
    ): void {

        if (
            !Number.isFinite(
                deltaTime,
            ) ||
            deltaTime <=
            0
        ) {
            return;
        }

        let stateChanged =
            false;

        for (
            const zone
            of this.zones
        ) {
            if (
                !zone.advanceStateTimer(
                    deltaTime,
                )
            ) {
                continue;
            }

            const zoneDefinition =
                zone.getDefinition();

            const stateDefinition =
                getSurfaceStateDefinition(
                    zoneDefinition.surfaceType,
                    zone.getCurrentState(),
                );

            if (
                stateDefinition.reversionState ===
                null
            ) {
                zone.setRuntimeState(
                    zone.getCurrentState(),
                    null,
                );

                continue;
            }

            this.applyStateToZone(
                zone,
                stateDefinition.reversionState,
                null,
            );

            stateChanged =
                true;
        }

        for (
            const region
            of this.stateRegions
        ) {
            if (
                !region.advanceStateTimer(
                    deltaTime,
                )
            ) {
                continue;
            }

            const definition =
                region.getDefinition();

            const currentStateDefinition =
                getSurfaceStateDefinition(
                    definition.surfaceType,
                    region.getCurrentState(),
                );

            const reversionState =
                definition.reversionState ??
                currentStateDefinition.reversionState;

            if (
                reversionState ===
                null
            ) {
                region.setRuntimeState(
                    region.getCurrentState(),
                    null,
                );

                continue;
            }

            this.validateStateForSurface(
                definition.surfaceType,
                reversionState,
            );

            region.setRuntimeState(
                reversionState,
                null,
            );

            stateChanged =
                true;
        }

        if (
            stateChanged
        ) {
            this.notifyChanged();
        }
    }

    // ---------------------------------------------------------------------
    // Base authored zones
    // ---------------------------------------------------------------------

    public addZone(
        definition:
            SurfaceZoneDefinition,
    ): SurfaceZone {

        if (
            this.zones.some(
                (
                    zone:
                        SurfaceZone,
                ): boolean =>
                    zone
                        .getDefinition()
                        .id ===
                    definition.id,
            )
        ) {
            throw new Error(
                `Surface zone id '${definition.id}' is duplicated.`,
            );
        }

        const surfaceDefinition =
            getSurfaceDefinition(
                definition.surfaceType,
            );

        this.validateStateForSurface(
            definition.surfaceType,
            surfaceDefinition.defaultState,
        );

        const zone =
            new SurfaceZone(
                definition,
                surfaceDefinition.defaultState,
            );

        this.zones.push(
            zone,
        );

        this.notifyChanged();

        return zone;
    }

    public clearZones(): void {

        if (
            this.zones.length ===
            0
        ) {
            return;
        }

        this.zones.length =
            0;

        this.notifyChanged();
    }

    // ---------------------------------------------------------------------
    // Runtime state regions
    // ---------------------------------------------------------------------

    public addStateRegion(
        definition:
            SurfaceStateRegionDefinition,
    ): boolean {

        if (
            this.stateRegions.some(
                (
                    region:
                        SurfaceStateRegion,
                ): boolean =>
                    region
                        .getDefinition()
                        .id ===
                    definition.id,
            )
        ) {
            return false;
        }

        this.validateStateForSurface(
            definition.surfaceType,
            definition.state,
        );

        if (
            definition.reversionState !==
            null
        ) {
            this.validateStateForSurface(
                definition.surfaceType,
                definition.reversionState,
            );
        }

        if (
            definition.durationSeconds !==
            null &&
            definition.reversionState ===
            null &&
            getSurfaceStateDefinition(
                definition.surfaceType,
                definition.state,
            )
                .reversionState ===
            null
        ) {
            throw new Error(
                `Surface state region '${definition.id}' cannot use a temporary duration because its state has no reversion state.`,
            );
        }

        this.stateRegions.push(
            new SurfaceStateRegion(
                definition,
            ),
        );

        this.notifyChanged();

        return true;
    }

    public clearStateRegions():
        void {

        if (
            this.stateRegions.length ===
            0
        ) {
            return;
        }

        this.stateRegions.length =
            0;

        this.notifyChanged();
    }

    public removeStateRegionsByIdPrefix(
        idPrefix:
            string,
    ): number {

        if (idPrefix.length === 0) {
            return 0;
        }

        let removedCount = 0;

        for (
            let index = this.stateRegions.length - 1;
            index >= 0;
            index -= 1
        ) {
            const region = this.stateRegions[index];

            if (
                !region ||
                !region.getDefinition().id.startsWith(idPrefix)
            ) {
                continue;
            }

            this.stateRegions.splice(index, 1);
            removedCount += 1;
        }

        if (removedCount > 0) {
            this.notifyChanged();
        }

        return removedCount;
    }

    public getStateRegions():
        readonly SurfaceStateRegion[] {

        return this.stateRegions;
    }

    // ---------------------------------------------------------------------
    // Queries
    // ---------------------------------------------------------------------

    public getSurfaceAt(
        worldX:
            number,

        worldY:
            number,
    ): SurfaceSample {

        const baseSample =
            this.getBaseSurfaceAt(
                worldX,
                worldY,
            );

        /*
         * Explicit runtime state regions have the highest categorical
         * precedence. This preserves Fire scorch regions and any deliberately
         * authored/runtime Wet regions.
         */
        for (
            let regionIndex =
                this.stateRegions.length -
                1;

            regionIndex >= 0;

            regionIndex -= 1
        ) {
            const region =
                this.stateRegions[
                regionIndex
                ];

            if (
                !region ||
                !region.containsPoint(
                    worldX,
                    worldY,
                )
            ) {
                continue;
            }

            const definition =
                region.getDefinition();

            if (
                definition.surfaceType !==
                baseSample.surfaceType
            ) {
                continue;
            }

            return this.createSampleForState(
                baseSample,
                region.getCurrentState(),
            );
        }

        /*
         * If an authored zone is currently in a non-default state, treat that
         * as an explicit categorical choice and preserve it. A moisture-derived
         * state must not silently overwrite an authored Wet zone or a zone that
         * has been explicitly changed to Scorched.
         */
        if (
            baseSample.zoneId !==
            null
        ) {
            const defaultState =
                getSurfaceDefinition(
                    baseSample
                        .surfaceType,
                )
                    .defaultState;

            if (
                baseSample.surfaceState !==
                defaultState
            ) {
                return baseSample;
            }
        }

        if (
            this.derivedStateResolvers.size ===
            0
        ) {
            return baseSample;
        }

        /*
         * Later-registered derived resolvers have higher derived precedence.
         * All of them remain below explicit state regions and explicit authored
         * zone state.
         */
        const resolvers =
            [
                ...this.derivedStateResolvers
                    .values(),
            ];

        for (
            let resolverIndex =
                resolvers.length -
                1;

            resolverIndex >= 0;

            resolverIndex -= 1
        ) {
            const resolver =
                resolvers[
                resolverIndex
                ];

            if (!resolver) {
                continue;
            }

            const derivedState =
                resolver(
                    worldX,
                    worldY,
                    baseSample,
                );

            if (
                derivedState ===
                null
            ) {
                continue;
            }

            this.validateStateForSurface(
                baseSample.surfaceType,
                derivedState,
            );

            return this.createSampleForState(
                baseSample,
                derivedState,
            );
        }

        return baseSample;
    }

    /**
     * Registers one derived categorical state source without creating runtime
     * SurfaceStateRegions. Resolver ids are unique so ownership is explicit.
     *
     * Returns an idempotent unregister callback.
     */
    public registerDerivedStateResolver(
        id:
            string,

        resolver:
            SurfaceDerivedStateResolver,
    ): () => void {
        if (
            id.trim().length ===
            0
        ) {
            throw new Error(
                "Surface derived-state resolver id cannot be empty.",
            );
        }

        if (
            this.derivedStateResolvers
                .has(
                    id,
                )
        ) {
            throw new Error(
                `Surface derived-state resolver id '${id}' is duplicated.`,
            );
        }

        this.derivedStateResolvers
            .set(
                id,
                resolver,
            );

        this.notifyChanged();

        let unregistered =
            false;

        return (): void => {
            if (
                unregistered
            ) {
                return;
            }

            unregistered =
                true;

            if (
                this.derivedStateResolvers
                    .delete(
                        id,
                    )
            ) {
                this.notifyChanged();
            }
        };
    }

    /**
     * Called by a derived-state owner when its internal classification changes.
     * Gameplay queries already read live state, while listeners can redraw
     * presentation if they depend on SurfaceSystem.
     */
    public notifyDerivedStateChanged():
        void {
        this.notifyChanged();
    }

    public setZoneState(
        zoneId:
            string,

        state:
            SurfaceState,

        durationSeconds?:
            number | null,
    ): boolean {

        const zone =
            this.zones.find(
                (
                    candidate:
                        SurfaceZone,
                ): boolean =>
                    candidate
                        .getDefinition()
                        .id ===
                    zoneId,
            );

        if (
            !zone
        ) {
            return false;
        }

        this.applyStateToZone(
            zone,
            state,
            durationSeconds,
        );

        this.notifyChanged();

        return true;
    }

    public setSurfaceStateAt(
        worldX:
            number,

        worldY:
            number,

        state:
            SurfaceState,

        durationSeconds?:
            number | null,
    ): boolean {

        for (
            let zoneIndex =
                this.zones.length -
                1;

            zoneIndex >= 0;

            zoneIndex -= 1
        ) {
            const zone =
                this.zones[
                zoneIndex
                ];

            if (
                !zone ||
                !zone.containsPoint(
                    worldX,
                    worldY,
                )
            ) {
                continue;
            }

            this.applyStateToZone(
                zone,
                state,
                durationSeconds,
            );

            this.notifyChanged();

            return true;
        }

        return false;
    }

    public subscribeToChanges(
        listener:
            SurfaceChangeListener,
    ): () => void {

        this.changeListeners.add(
            listener,
        );

        let unsubscribed =
            false;

        return (): void => {

            if (
                unsubscribed
            ) {
                return;
            }

            unsubscribed =
                true;

            this.changeListeners.delete(
                listener,
            );
        };
    }

    public getZones():
        readonly SurfaceZone[] {

        return this.zones;
    }

    public getDefaultSurface():
        SurfaceSample {

        const definition =
            getSurfaceDefinition(
                this.defaultSurfaceType,
            );

        const stateDefinition =
            getSurfaceStateDefinition(
                this.defaultSurfaceType,
                definition.defaultState,
            );

        return {
            surfaceType:
                this.defaultSurfaceType,

            surfaceState:
                definition.defaultState,

            rollingResistanceMultiplier:
                stateDefinition
                    .rollingResistanceMultiplier,

            zoneId:
                null,
        };
    }

    // ---------------------------------------------------------------------
    // Internal base terrain resolution
    // ---------------------------------------------------------------------

    private getBaseSurfaceAt(
        worldX:
            number,

        worldY:
            number,
    ): SurfaceSample {

        for (
            let zoneIndex =
                this.zones.length -
                1;

            zoneIndex >= 0;

            zoneIndex -= 1
        ) {
            const zone =
                this.zones[
                zoneIndex
                ];

            if (
                !zone ||
                !zone.containsPoint(
                    worldX,
                    worldY,
                )
            ) {
                continue;
            }

            return this.createSampleForZone(
                zone,
            );
        }

        const defaultDefinition =
            getSurfaceDefinition(
                this.defaultSurfaceType,
            );

        const stateDefinition =
            getSurfaceStateDefinition(
                this.defaultSurfaceType,
                defaultDefinition.defaultState,
            );

        this.validateStateDefinition(
            stateDefinition
                .rollingResistanceMultiplier,
            this.defaultSurfaceType,
            defaultDefinition.defaultState,
        );

        return {
            surfaceType:
                this.defaultSurfaceType,

            surfaceState:
                defaultDefinition.defaultState,

            rollingResistanceMultiplier:
                stateDefinition
                    .rollingResistanceMultiplier,

            zoneId:
                null,
        };
    }

    private createSampleForZone(
        zone:
            SurfaceZone,
    ): SurfaceSample {

        const zoneDefinition =
            zone.getDefinition();

        const currentState =
            zone.getCurrentState();

        const stateDefinition =
            getSurfaceStateDefinition(
                zoneDefinition.surfaceType,
                currentState,
            );

        this.validateStateDefinition(
            stateDefinition
                .rollingResistanceMultiplier,
            zoneDefinition.surfaceType,
            currentState,
        );

        return {
            surfaceType:
                zoneDefinition.surfaceType,

            surfaceState:
                currentState,

            rollingResistanceMultiplier:
                stateDefinition
                    .rollingResistanceMultiplier,

            zoneId:
                zoneDefinition.id,
        };
    }

    private createSampleForState(
        baseSample:
            SurfaceSample,

        state:
            SurfaceState,
    ): SurfaceSample {
        const stateDefinition =
            getSurfaceStateDefinition(
                baseSample.surfaceType,
                state,
            );

        this.validateStateDefinition(
            stateDefinition
                .rollingResistanceMultiplier,
            baseSample.surfaceType,
            state,
        );

        return {
            surfaceType:
                baseSample.surfaceType,

            surfaceState:
                state,

            rollingResistanceMultiplier:
                stateDefinition
                    .rollingResistanceMultiplier,

            zoneId:
                baseSample.zoneId,
        };
    }

    private applyStateToZone(
        zone:
            SurfaceZone,

        state:
            SurfaceState,

        durationSeconds?:
            number | null,
    ): void {

        const zoneDefinition =
            zone.getDefinition();

        this.validateStateForSurface(
            zoneDefinition.surfaceType,
            state,
        );

        const stateDefinition =
            getSurfaceStateDefinition(
                zoneDefinition.surfaceType,
                state,
            );

        const resolvedDuration =
            durationSeconds ===
                undefined
                ? stateDefinition
                    .durationSeconds
                : durationSeconds;

        if (
            resolvedDuration !== null &&
            stateDefinition.reversionState ===
            null
        ) {
            throw new Error(
                `Surface '${zoneDefinition.surfaceType}' state '${state}' cannot use a temporary duration because it has no reversion state.`,
            );
        }

        zone.setRuntimeState(
            state,
            resolvedDuration,
        );
    }

    private validateStateForSurface(
        surfaceType:
            SurfaceType,

        state:
            SurfaceState,
    ): void {

        if (
            !isSurfaceStateAllowed(
                surfaceType,
                state,
            )
        ) {
            throw new Error(
                `Surface '${surfaceType}' does not allow state '${state}'.`,
            );
        }

        const definition =
            getSurfaceStateDefinition(
                surfaceType,
                state,
            );

        this.validateStateDefinition(
            definition
                .rollingResistanceMultiplier,
            surfaceType,
            state,
        );
    }

    private validateStateDefinition(
        rollingResistanceMultiplier:
            number,

        surfaceType:
            SurfaceType,

        state:
            SurfaceState,
    ): void {

        if (
            !Number.isFinite(
                rollingResistanceMultiplier,
            ) ||
            rollingResistanceMultiplier <=
            0
        ) {
            throw new Error(
                `Surface '${surfaceType}' state '${state}' rollingResistanceMultiplier must be a finite number greater than zero.`,
            );
        }
    }

    private notifyChanged():
        void {

        this.changeListeners.forEach(
            (
                listener:
                    SurfaceChangeListener,
            ): void => {

                listener();
            },
        );
    }
}
