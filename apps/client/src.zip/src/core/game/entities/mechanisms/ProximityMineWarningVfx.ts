import { Container, Graphics } from 'pixi.js';
import { PROXIMITY_MINE_DEFINITION as D } from '../../config/ProximityMineDefinition';
interface Ring { graphics: Graphics; age: number; }
/** Visual-only, bounded and pooled by destruction on expiration. */
export class ProximityMineWarningVfx {
    public readonly container = new Container();
    private readonly rings: Ring[] = [];
    public emit(): void {
        if (this.rings.length >= D.sonarMaximumCount) {
            const oldest = this.rings.shift();
            if (oldest) { this.container.removeChild(oldest.graphics); oldest.graphics.destroy(); }
        }
        const graphics = new Graphics();
        this.container.addChild(graphics);
        this.rings.push({ graphics, age: 0 });
    }
    public update(dt: number): void {
        for (let i = this.rings.length - 1; i >= 0; i--) {
            const ring = this.rings[i];
            ring.age += dt;
            if (ring.age >= D.sonarDurationSeconds) {
                this.container.removeChild(ring.graphics);
                ring.graphics.destroy();
                this.rings.splice(i, 1);
                continue;
            }
            const t = ring.age / D.sonarDurationSeconds;
            ring.graphics.clear().circle(0, 0, D.bodyRadius + t * (D.sonarMaximumRadius - D.bodyRadius))
                .stroke({ color: D.color, width: 2.5 * (1 - t) + 0.4, alpha: (1 - t) * 0.85 });
        }
    }
    public destroy(): void {
        for (const ring of this.rings) ring.graphics.destroy();
        this.rings.length = 0;
        this.container.destroy();
    }
}
