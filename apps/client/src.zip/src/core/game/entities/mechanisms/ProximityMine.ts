import { Graphics, Text } from 'pixi.js';
import { Entity } from '../Entity';
import { PROXIMITY_MINE_DEFINITION as D } from '../../config/ProximityMineDefinition';
import { detectProximityMineTarget, type ProximityMineTarget } from './ProximityMineDetection';
import { ProximityMineWarningVfx } from './ProximityMineWarningVfx';
export type ProximityMineState = 'IDLE' | 'WARNING' | 'DETONATED';
/** PM-1: non-destructive detonation marker. PM-2 will consume detonation events. */
export class ProximityMine extends Entity {
    private readonly body = new Graphics();
    private readonly led = new Graphics();
    private readonly warningVfx = new ProximityMineWarningVfx();
    private readonly debug = new Text({ text: '', style: { fontSize: 11, fill: 0xffffff,
        stroke: { color: 0x202030, width: 3 }, align: 'center' } });
    private targets: readonly ProximityMineTarget[] = [];
    private state: ProximityMineState = 'IDLE';
    private warningSeconds = 0;
    private beepClock = 0;
    private ledSeconds = 0;
    private detected = 'none';
    private explodedBy = 'none';
    private detonationPending = false;
    constructor(public readonly mineId: string, x: number, y: number) { super(); this.setPosition(x, y); }
    public setTargets(targets: readonly ProximityMineTarget[]): void { this.targets = targets; }
    public getState(): ProximityMineState { return this.state; }
    public consumeDetonation(): { mineId: string; target: string; x: number; y: number } | null {
        if (!this.detonationPending) return null;
        this.detonationPending = false;
        return { mineId: this.mineId, target: this.explodedBy, x: this.getX(), y: this.getY() };
    }
    protected onInitialize(): void {
        this.body.circle(0, 0, D.bodyRadius).fill(0x69717f)
            .stroke({ color: 0x303746, width: 3 });
        this.body.moveTo(-9, -9).lineTo(9, 9).moveTo(9, -9).lineTo(-9, 9)
            .stroke({ color: 0x292d3b, width: 4, cap: 'round' });
        this.container.addChild(this.warningVfx.container, this.body, this.led);
        this.debug.anchor.set(0.5, 1);
        this.debug.position.set(0, -D.bodyRadius - 11);
        if (D.debugEnabled) this.container.addChild(this.debug);
        this.drawLed(false);
    }
    private drawLed(on: boolean): void {
        this.led.clear().circle(0, 0, 5.5).fill(on ? D.color : 0x4c2735)
            .stroke({ color: on ? 0xffb5d0 : 0x292d3b, width: 1.3 });
    }
    private detonate(target: string): void {
        this.state = 'DETONATED';
        this.explodedBy = target;
        this.detonationPending = true;
        this.warningVfx.emit();
        this.ledSeconds = 0;
        this.drawLed(true);
    }
    protected onUpdate(dt: number): void {
        const delta = Math.max(0, Math.min(dt, 0.1));
        if (this.state !== 'DETONATED') {
            const result = detectProximityMineTarget(this.getX(), this.getY(), this.targets,
                D.detectionRadius, D.contactRadius);
            this.detected = result.target?.label ?? 'none';
            if (result.contact && result.target) {
                this.detonate(result.target.label);
            } else {
                this.warningSeconds = result.target
                    ? Math.min(D.warningThresholdSeconds, this.warningSeconds + delta)
                    : Math.max(0, this.warningSeconds - delta * D.warningDecayPerSecond);
                this.state = result.target ? 'WARNING' : 'IDLE';
                if (this.warningSeconds >= D.warningThresholdSeconds && result.target) {
                    this.detonate(result.target.label);
                } else {
                    const intensity = this.warningSeconds / D.warningThresholdSeconds;
                    const interval = D.idleBeepIntervalSeconds +
                        (D.minimumBeepIntervalSeconds - D.idleBeepIntervalSeconds) * intensity;
                    this.beepClock += delta;
                    if (this.beepClock >= interval) {
                        this.beepClock = 0;
                        this.ledSeconds = 0.11;
                        this.warningVfx.emit();
                    }
                }
            }
        }
        this.ledSeconds = Math.max(0, this.ledSeconds - delta);
        this.drawLed(this.state === 'DETONATED' || this.ledSeconds > 0);
        this.warningVfx.update(delta);
        if (D.debugEnabled) this.debug.text = `${this.mineId} [${this.state}]\nDetected: ${this.detected}\nWarning: ${this.warningSeconds.toFixed(1)}/${D.warningThresholdSeconds.toFixed(1)}s\nExploded object: ${this.explodedBy}`;
    }
    protected onDestroy(): void { this.container.removeChild(this.warningVfx.container); this.warningVfx.destroy(); this.container.destroy({ children: true }); }
}
