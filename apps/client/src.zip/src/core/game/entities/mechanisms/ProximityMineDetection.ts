/** Pure proximity selection. Radii account for the target's physical footprint. */
export interface ProximityMineTarget {
    readonly id: string;
    readonly label: string;
    readonly x: number;
    readonly y: number;
    readonly radius: number;
}
export interface ProximityMineDetectionResult {
    readonly target: ProximityMineTarget | null;
    readonly distanceToSurface: number;
    readonly contact: boolean;
}
export function detectProximityMineTarget(
    x: number, y: number, targets: readonly ProximityMineTarget[],
    detectionRadius: number, contactRadius: number,
): ProximityMineDetectionResult {
    let nearest: ProximityMineTarget | null = null;
    let nearestSurface = Infinity;
    for (const target of targets) {
        const distance = Math.hypot(target.x - x, target.y - y);
        const surface = Math.max(0, distance - Math.max(0, target.radius));
        if (surface <= detectionRadius && surface < nearestSurface) {
            nearest = target;
            nearestSurface = surface;
        }
    }
    return { target: nearest, distanceToSurface: nearestSurface,
        contact: nearest !== null && nearestSurface <= contactRadius };
}
