export interface WaterVfxPoolDefinition {
    readonly initialCapacity: number;
    readonly maximumCapacity: number;
}

export interface WaterVfxParticleDefinition {
    readonly gravityX: number;
    readonly gravityY: number;
    readonly dragPerSecond: number;
    readonly fadeStartFraction: number;
}

export interface WaterVfxStreamDefinition {
    readonly minimumLength: number;
    readonly minimumWidth: number;
    readonly maximumWidth: number;
    readonly bodyColor: number;
    readonly highlightColor: number;
    readonly bodyAlpha: number;
    readonly highlightAlpha: number;
    readonly highlightWidthFraction: number;
}


export interface HoseWaterVfxDefinition {
    readonly enabled: boolean;

    /** Width at the physical Hose nozzle. */
    readonly startWidth: number;

    /** Width through the coherent middle of the pressure jet. */
    readonly middleWidth: number;

    /** Width toward the authoritative downstream end of the jet. */
    readonly endWidth: number;

    /** Hard presentation floor. Organic deformation may never cross this. */
    readonly minimumBodyWidth: number;

    /** Scales edge disturbance progressively toward the downstream end. */
    readonly downstreamDisturbanceMultiplier: number;

    readonly bodyColor: number;
    readonly bodyAlpha: number;

    /** 8I-6B.3 world-space length represented by one full flow-noise repeat. */
    readonly flowTextureWorldLength: number;

    /**
     * Fallback downstream speed when authoritative packet transport cannot be
     * estimated reliably.
     */
    readonly flowTextureSpeed: number;

    /** Scale applied to the current authoritative Hose transport estimate. */
    readonly flowTransportSpeedScale: number;

    /** Safety bounds for presentation-only texture transport. */
    readonly minimumFlowTextureSpeed: number;
    readonly maximumFlowTextureSpeed: number;

    /** Current-frame-only centerline smoothing passes. Endpoints stay fixed. */
    readonly centerlineSmoothingPasses: number;

    /**
     * 8I-6C.1 trajectory reconstruction.
     * Minimum age separation between retained authoritative packet samples.
     * This prevents over-dense near-identical packets from flattening bends.
     */
    readonly trajectoryMinimumAgeStepSeconds: number;

    /**
     * Minimum directional change worth retaining as a trajectory control point.
     * Expressed in radians and used only by presentation reconstruction.
     */
    readonly trajectoryTurnRetentionRadians: number;

    /**
     * Number of bend-preserving centerline smoothing passes.
     * This smoothing never changes authoritative packet state.
     */
    readonly trajectorySmoothingPasses: number;

    /** 8I-6C.2 angular nozzle velocity is the primary disturbance driver. */
    readonly motionAngularVelocityForFullIntensity: number;

    /** Linear nozzle velocity contributes secondarily to disturbance. */
    readonly motionLinearVelocityForFullIntensity: number;

    /** Relative weight of angular movement in the combined motion signal. */
    readonly motionAngularWeight: number;

    /** Relative weight of linear movement in the combined motion signal. */
    readonly motionLinearWeight: number;

    /** Maximum extra multiplier applied to downstream edge disturbance. */
    readonly motionDisturbanceBoost: number;

    /** 8I-6C.3 maximum extra downstream body width at full motion. */
    readonly motionMaximumWidthBonus: number;

    /** Downstream ramp exponent for presentation-only motion broadening. */
    readonly motionWidthRampExponent: number;

    /** Seconds for residual broadening to settle after movement decreases. */
    readonly motionWidthRecoverySeconds: number;

    /** 8I-6C.4 motion intensity required before breakup can appear. */
    readonly breakupThreshold: number;

    /** Hard presentation-only fragment limit. */
    readonly breakupMaximumFragments: number;

    /** Lifetime range for detached downstream lobes. */
    readonly breakupMinimumLifetimeSeconds: number;
    readonly breakupMaximumLifetimeSeconds: number;

    /** Fragment dimensions relative to the terminal Hose body width. */
    readonly breakupMinimumSizeFraction: number;
    readonly breakupMaximumSizeFraction: number;

    /** Initial separation and downstream travel speed. */
    readonly breakupMinimumSeparation: number;
    readonly breakupMaximumSeparation: number;
    readonly breakupTravelSpeed: number;

    /** Contrast applied while converting grayscale mask values to Water colour. */
    readonly flowTextureContrast: number;

    /** Maximum influence of the light end of the grayscale mask. */
    readonly flowTextureStrength: number;

    /** 8I-6B.5 toon remap for large readable Water highlight masses. */
    readonly toonMidColor: number;
    readonly toonMidThreshold: number;
    readonly toonHighlightThreshold: number;
    readonly toonMaskBlurPixels: number;

    /**
     * 8I-6B.5A large travelling highlight masses.
     * These deliberately survive the narrow gameplay-scale Hose mesh.
     */
    readonly toonMassCount: number;
    readonly toonMassLengthFraction: number;
    readonly toonMassWidthFraction: number;
    readonly toonMassAsymmetry: number;

    /** Presentation-only organic cap lengths, measured in world pixels. */
    readonly sourceCapLength: number;
    readonly downstreamCapLength: number;

    /** Presentation-only centerline reconstruction spacing. */
    readonly resampleSpacing: number;

    /** Restrained current-frame organic movement. No trajectory history is stored. */
    readonly centerWaveAmplitude: number;
    readonly centerWaveFrequency: number;
    readonly centerWaveSpeed: number;

    /** Independent left/right silhouette breakup. */
    readonly edgeWaveAmplitude: number;
    readonly edgeWaveFrequency: number;
    readonly edgeWaveSpeed: number;

    /** 8I-6B.4 broad, low-frequency body compression/expansion. */
    readonly widthSquishAmplitude: number;
    readonly widthSquishFrequency: number;
    readonly widthSquishSpeed: number;

    /** 8I-6B.4 additional asymmetric small-scale edge deformation. */
    readonly edgeIrregularityAmplitude: number;
    readonly edgeIrregularityFrequency: number;
    readonly edgeIrregularitySpeed: number;

    /**
     * 8I-6B.4 current-packet directional spread. This is presentation only:
     * fast changes in the live packet path widen the downstream jet.
     */
    readonly movementSpreadScale: number;
    readonly maximumMovementSpread: number;
    readonly movementSpreadRampExponent: number;

    /** 8I-6B animated broken inner streak. */
    readonly highlightColor: number;
    readonly highlightAlpha: number;
    readonly highlightWidthFraction: number;
    readonly highlightLength: number;
    readonly highlightSpacing: number;
    readonly highlightSpeed: number;

    /** 8I-6B smaller secondary highlight fragments. */
    readonly fragmentColor: number;
    readonly fragmentAlpha: number;
    readonly fragmentWidthFraction: number;
    readonly fragmentLength: number;
    readonly fragmentSpacing: number;
    readonly fragmentSpeed: number;
}

export interface SprinklerWaterVfxDefinition {
    readonly enabled: boolean;

    /** 8I-7A fragmented-jet dimensions across authoritative packet flight. */
    readonly nearDropletLength: number;
    readonly middleDropletLength: number;
    readonly farDropletLength: number;
    readonly nearDropletWidth: number;
    readonly middleDropletWidth: number;
    readonly farDropletWidth: number;

    /** Age boundaries for coherent jet -> broken segment -> terminal droplet. */
    readonly nearStageEndAgeSeconds: number;
    readonly middleStageEndAgeSeconds: number;
    readonly terminalDropletStartAgeSeconds: number;

    /** Taper and downstream breakup keep marks directional rather than capsule-like. */
    readonly tailWidthFraction: number;
    readonly noseWidthFraction: number;
    readonly downstreamVariationMultiplier: number;

    /** 8I-7A.1 deterministic per-packet variation without lateral jitter. */
    readonly packetLengthVariation: number;
    readonly packetWidthVariation: number;
    readonly packetSpacingVariation: number;
    readonly bodyColor: number;
    readonly bodyAlpha: number;
    readonly highlightColor: number;
    readonly highlightAlpha: number;
    readonly highlightLengthFraction: number;
    readonly highlightWidthFraction: number;

    /** Small deterministic variation keeps the spray hand-drawn rather than cloned. */
    readonly lengthVariation: number;
    readonly widthVariation: number;
    readonly rotationVariationRadians: number;

    /** Render every Nth authoritative packet. 1 preserves the original gameplay read. */
    readonly visualPacketStride: number;

    /** Fade only near the end of an authoritative packet's airborne life. */
    readonly fadeStartAgeSeconds: number;
    readonly fadeDurationSeconds: number;

    /** Gentle visual pulse. Position always remains authoritative. */
    readonly pulseAmplitude: number;
    readonly pulseSpeed: number;
}

export interface WaterVfxDefinition {
    readonly enabled: boolean;
    readonly pool: WaterVfxPoolDefinition;
    readonly particle: WaterVfxParticleDefinition;
    readonly stream: WaterVfxStreamDefinition;
    readonly hose: HoseWaterVfxDefinition;
    readonly sprinkler: SprinklerWaterVfxDefinition;
    readonly dropletColor: number;
    readonly highlightColor: number;
}

export const DEFAULT_WATER_VFX_DEFINITION: WaterVfxDefinition = {
    enabled: true,

    pool: {
        initialCapacity: 96,
        maximumCapacity: 384,
    },

    particle: {
        gravityX: 0,
        gravityY: 180,
        dragPerSecond: 0.12,
        fadeStartFraction: 0.72,
    },

    stream: {
        minimumLength: 0.5,
        minimumWidth: 1.5,
        maximumWidth: 28,
        bodyColor: 0x279ed1,
        highlightColor: 0xbdefff,
        bodyAlpha: 0.96,
        highlightAlpha: 0.78,
        highlightWidthFraction: 0.24,
    },


    hose: {
        enabled: true,

        // 8I-6B.5: readable high-pressure Water body at gameplay zoom.
        // 8I-6B.5B pressure-jet profile: substantial core all the way down.
        startWidth: 10,
        middleWidth: 25,
        endWidth: 50,
        minimumBodyWidth: 10,
        downstreamDisturbanceMultiplier: 1,
        bodyColor: 0x49c9ee,
        bodyAlpha: 0.98,

        // 8I-6B.3 textured internal Water flow.
        // Larger forms and much faster motion read as pressurised Water.
        flowTextureWorldLength: 300,
        flowTextureSpeed: 360,
        flowTransportSpeedScale: 0.90,
        minimumFlowTextureSpeed: 300,
        maximumFlowTextureSpeed: 900,
        centerlineSmoothingPasses: 2,

        // 8I-6C.1: preserve packet-history bends instead of flattening them.
        trajectoryMinimumAgeStepSeconds: 0.025,
        trajectoryTurnRetentionRadians: 0.035,
        trajectorySmoothingPasses: 1,

        // 8I-6C.2: rotation dominates; translation is deliberately secondary.
        motionAngularVelocityForFullIntensity: 5.5,
        motionLinearVelocityForFullIntensity: 650,
        motionAngularWeight: 0.82,
        motionLinearWeight: 0.18,
        motionDisturbanceBoost: 1.35,

        // 8I-6C.3: source stays tight; full movement adds at most 10 px
        // near the downstream end, then settles smoothly back to baseline.
        motionMaximumWidthBonus: 10,
        motionWidthRampExponent: 1.65,
        motionWidthRecoverySeconds: 0.25,

        // 8I-6C.4: breakup is reserved for genuinely violent Hose motion.
        breakupThreshold: 0.88,
        breakupMaximumFragments: 3,
        breakupMinimumLifetimeSeconds: 0.10,
        breakupMaximumLifetimeSeconds: 0.22,
        breakupMinimumSizeFraction: 0.12,
        breakupMaximumSizeFraction: 0.24,
        breakupMinimumSeparation: 5,
        breakupMaximumSeparation: 16,
        breakupTravelSpeed: 95,

        flowTextureContrast: 1.10,
        flowTextureStrength: 1.0,

        // 8I-6B.5: convert fine grayscale noise into large flat graphic masses.
        toonMidColor: 0x8fe7fa,
        toonMidThreshold: 0.60,
        toonHighlightThreshold: 0.84,
        toonMaskBlurPixels: 12,

        // 8I-6B.5A: broad cyan masses replace persistent hairline streaks.
        toonMassCount: 7,
        toonMassLengthFraction: 0.19,
        toonMassWidthFraction: 0.62,
        toonMassAsymmetry: 0.28,

        // Rounded/organic mesh terminals. The source cap is normally hidden
        // beneath the Hose nozzle; the downstream cap remains clearly visible.
        sourceCapLength: 5,
        downstreamCapLength: 8,

        resampleSpacing: 7,

        // Larger and slower silhouette motion survives normal gameplay zoom.
        centerWaveAmplitude: 0.65,
        centerWaveFrequency: 0.022,
        centerWaveSpeed: 1.55,

        edgeWaveAmplitude: 1.8,
        edgeWaveFrequency: 0.018,
        edgeWaveSpeed: 1.15,

        // 8I-6B.5A: stronger, slower body-volume changes at gameplay zoom.
        widthSquishAmplitude: 0,
        widthSquishFrequency: 0.010,
        widthSquishSpeed: 0.95,

        // Lower frequency and stronger asymmetry prevents parallel ribbon edges.
        edgeIrregularityAmplitude: 0.65,
        edgeIrregularityFrequency: 0.014,
        edgeIrregularitySpeed: 0.95,

        movementSpreadScale: 18,
        maximumMovementSpread: 10,
        movementSpreadRampExponent: 1.35,

        highlightColor: 0xe8fbff,
        highlightAlpha: 0,
        highlightWidthFraction: 0.34,
        highlightLength: 34,
        highlightSpacing: 68,
        highlightSpeed: 105,

        fragmentColor: 0xe8fbff,
        fragmentAlpha: 0,
        fragmentWidthFraction: 0.18,
        fragmentLength: 12,
        fragmentSpacing: 86,
        fragmentSpeed: 78,
    },

    sprinkler: {
        enabled: true,

        // 8I-7A fragmented sprinkler jet. Independent authoritative packets
        // read as coherent segments near the nozzle and progressively break up.
        nearDropletLength: 25,
        middleDropletLength: 19,
        farDropletLength: 12,
        nearDropletWidth: 6.4,
        middleDropletWidth: 5.5,
        farDropletWidth: 4.2,

        nearStageEndAgeSeconds: 0.20,
        middleStageEndAgeSeconds: 0.48,
        terminalDropletStartAgeSeconds: 0.68,

        tailWidthFraction: 0.58,
        noseWidthFraction: 0.22,
        downstreamVariationMultiplier: 1.65,

        // 8I-7A.1: break stamped repetition while preserving radial precision.
        packetLengthVariation: 0.13,
        packetWidthVariation: 0.11,
        packetSpacingVariation: 0.12,
        bodyColor: 0x49c9ee,
        bodyAlpha: 0.96,
        highlightColor: 0xe8fbff,
        highlightAlpha: 0.82,
        highlightLengthFraction: 0.42,
        highlightWidthFraction: 0.34,

        lengthVariation: 0.14,
        widthVariation: 0.10,
        rotationVariationRadians: 0.045,

        visualPacketStride: 1,

        fadeStartAgeSeconds: 0.72,
        fadeDurationSeconds: 0.22,

        pulseAmplitude: 0.045,
        pulseSpeed: 5.5,
    },

    dropletColor: 0x43b8e8,
    highlightColor: 0xcaf4ff,
};
