/** PM-1 prototype only: detonation is an event, not yet a damaging explosion. */
export const PROXIMITY_MINE_DEFINITION = {
    bodyRadius: 17,
    contactRadius: 19,
    detectionRadius: 110,
    warningThresholdSeconds: 3,
    idleBeepIntervalSeconds: 2,
    minimumBeepIntervalSeconds: 0.2,
    sonarDurationSeconds: 0.75,
    sonarMaximumRadius: 86,
    sonarMaximumCount: 12,
    warningDecayPerSecond: 1.5,
    debugEnabled: true,
    color: 0xdd3e80,
} as const;
