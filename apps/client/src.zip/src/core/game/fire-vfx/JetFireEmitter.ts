import {
    DEFAULT_FIRE_PARTICLE_VFX_DEFINITION,
} from "../config/FireParticleVfxDefinition";

import type {
    FireParticleMaterialLayer,
    FireParticleThermalRoleDefinition,
    FireParticleVfxDefinition,
} from "../config/FireParticleVfxDefinition";

import {
    FireSourceType,
} from "../config/FireSourceDefinition";

import {
    DEFAULT_JET_FIRE_VFX_DEFINITION,
} from "../config/JetFireVfxDefinition";

import {
    DEFAULT_JET_FIRE_PRESENTATION_DEFINITION,
} from "../config/JetFirePresentationDefinition";

import type {
    JetFirePresentationDefinition,
} from "../config/JetFirePresentationDefinition";

import type {
    JetFireVfxDefinition,
} from "../config/JetFireVfxDefinition";

import type {
    FireSource,
} from "../environment/FireSource";

import type {
    FireSourceSystem,
} from "../environment/FireSourceSystem";

import type {
    LocalWindSystem,
} from "../environment/LocalWindSystem";

import type {
    FireVfxParticleActivation,
} from "./FireVfxParticle";

import type {
    FireVfxTextureVariant,
} from "./FireVfxSystem";

import {
    DIRECTIONAL_FIRE_PRESENTATION_CONTRACT,
} from "./FirePresentationContract";

import type {
    DirectionalFirePresentationRegion,
} from "./DirectionalFirePresentationRegion";

export type JetFireEmitterSpawnCallback =
    (
        variant:
            FireVfxTextureVariant,

        materialLayer:
            FireParticleMaterialLayer,

        activation:
            FireVfxParticleActivation,
    ) => boolean;

interface JetFireEmitterState {
    fractionalCarry: number;
    lastSeenUpdate: number;
}

/**
 * FIRE-VFX-5 presentation bridge for authoritative Directional FireSource
 * records.
 *
 * FireSourceSystem
 *      ↓ read only
 * JetFireEmitter
 *      ↓
 * FireVfxSystem.emitParticle(...)
 *      ↓
 * shared FireVfxPool
 *
 * This class never deposits heat, ignites terrain or changes a FireSource.
 */
export class JetFireEmitter {
    private performanceSpawnAttempts = 0;
    private performanceSpawned = 0;
    private performanceSpawnSkipped = 0;
    private performanceActiveSources = 0;

    public beginPerformanceFrame(): void {
        this.performanceSpawnAttempts = 0;
        this.performanceSpawned = 0;
        this.performanceSpawnSkipped = 0;
        this.performanceActiveSources = 0;
    }

    public getPerformanceDetails() {
        return {
            spawnAttempts: this.performanceSpawnAttempts,
            spawned: this.performanceSpawned,
            skipped: this.performanceSpawnSkipped,
            activeSources: this.performanceActiveSources,
        };
    }


    public static readonly presentationContract =
        DIRECTIONAL_FIRE_PRESENTATION_CONTRACT;

    private readonly emitterStates =
        new Map<FireSource, JetFireEmitterState>();

    private updateSerial =
        0;

    public constructor(
        private readonly fireSourceSystem:
            FireSourceSystem,

        private readonly localWindSystem:
            LocalWindSystem,

        private readonly spawnParticle:
            JetFireEmitterSpawnCallback,

        private readonly directionalPresentationRegion:
            DirectionalFirePresentationRegion,

        private readonly definition:
            JetFireVfxDefinition =
            DEFAULT_JET_FIRE_VFX_DEFINITION,

        private readonly particleDefinition:
            FireParticleVfxDefinition =
            DEFAULT_FIRE_PARTICLE_VFX_DEFINITION,

        private readonly presentationDefinition:
            JetFirePresentationDefinition =
            DEFAULT_JET_FIRE_PRESENTATION_DEFINITION,
    ) {
    }


    public getPresentationRegion():
        DirectionalFirePresentationRegion {

        return this.directionalPresentationRegion;
    }

    public update(
        deltaTime:
            number,
    ): void {

        if (
            !this.definition.enabled ||
            !this.particleDefinition.enabled ||
            !Number.isFinite(deltaTime) ||
            deltaTime <=
            0
        ) {
            this.performanceActiveSources += 1;
            return;
        }

        this.updateSerial +=
            1;

        let sawDirectionalSource =
            false;

        this.performanceActiveSources = 0;

        for (
            const source
            of this.fireSourceSystem
                .getSources()
        ) {
            if (
                !source.isEnabled() ||
                source.getType() !==
                FireSourceType.Directional
            ) {
                continue;
            }

            sawDirectionalSource =
                true;

            const state =
                this.getOrCreateEmitterState(
                    source,
                );

            state.lastSeenUpdate =
                this.updateSerial;

            this.emitFromSource(
                source,
                state,
                deltaTime,
            );
        }

        if (!sawDirectionalSource) {
            this.emitterStates.clear();

            return;
        }

        this.cleanupInactiveEmitterStates();
    }

    public reset():
        void {

        this.emitterStates.clear();

        this.updateSerial =
            0;
    }

    public destroy():
        void {

        this.reset();
    }

    private emitFromSource(
        source:
            FireSource,

        state:
            JetFireEmitterState,

        deltaTime:
            number,
    ): void {

        state.fractionalCarry +=
            Math.max(
                0,
                this.definition
                    .particlesPerSecondPerSource *
                this.presentationDefinition
                    .emissionDensityMultiplier,
            ) *
            deltaTime;

        const requestedSpawnCount =
            Math.floor(
                state.fractionalCarry,
            );

        const spawnCount =
            Math.min(
                requestedSpawnCount,
                Math.max(
                    1,
                    this.definition
                        .maximumSpawnsPerSourcePerFrame,
                ),
            );

        state.fractionalCarry -=
            spawnCount;

        state.fractionalCarry =
            Math.min(
                state.fractionalCarry,
                Math.max(
                    1,
                    this.definition
                        .emitterState
                        .maximumCarryParticles,
                ),
            );

        for (
            let index = 0;
            index <
            spawnCount;
            index += 1
        ) {
            this.spawnOne(
                source,
            );
        }
    }

    private spawnOne(
        source:
            FireSource,
    ): void {

        const role =
            this.selectThermalRole();

        const materialLayer =
            this.selectMaterialLayer();

        const activation =
            this.createActivation(
                source,
                role,
            );

        this.spawnParticle(
            role.textureVariant,
            materialLayer,
            activation,
        );
    }

    private createActivation(
        source:
            FireSource,

        role:
            FireParticleThermalRoleDefinition,
    ): FireVfxParticleActivation {

        const particle =
            this.particleDefinition
                .particle;

        const sourceDirection =
            source.getDirectionRadians();

        const coneOffset =
            this.randomRange(
                -this.definition
                    .coneHalfAngleRadians,
                this.definition
                    .coneHalfAngleRadians,
            );

        const emissionDirection =
            sourceDirection +
            coneOffset;

        const directionX =
            Math.cos(
                emissionDirection,
            );

        const directionY =
            Math.sin(
                emissionDirection,
            );

        const perpendicularX =
            -directionY;

        const perpendicularY =
            directionX;

        const sourceDirectionX =
            Math.cos(
                sourceDirection,
            );

        const sourceDirectionY =
            Math.sin(
                sourceDirection,
            );

        const sourceId =
            source.getId();

        const sourceDefinition =
            source.getDefinition();

        const authoredLength =
            sourceDefinition.type ===
                FireSourceType.Directional
                ? sourceDefinition.length
                : 0;

        const sourceOriginX =
            source.getPositionX();

        const sourceOriginY =
            source.getPositionY();

        const spawnAngle =
            Math.random() *
            Math.PI *
            2;

        const spawnRadius =
            Math.sqrt(
                Math.random(),
            ) *
            Math.max(
                0,
                this.definition
                    .spawnRadius,
            );

        const spawnOffsetX =
            Math.cos(
                spawnAngle,
            ) *
            spawnRadius;

        const spawnOffsetY =
            Math.sin(
                spawnAngle,
            ) *
            spawnRadius;

        const spawnX =
            source.getPositionX() +
            sourceDirectionX *
            this.definition
                .spawnForwardOffset +
            spawnOffsetX;

        const spawnY =
            source.getPositionY() +
            sourceDirectionY *
            this.definition
                .spawnForwardOffset +
            spawnOffsetY;

        const forwardVelocity =
            this.randomRange(
                this.definition
                    .forwardVelocityMinimum,
                this.definition
                    .forwardVelocityMaximum,
            ) *
            Math.max(
                0,
                role.speedMultiplier,
            ) *
            Math.max(
                0,
                this.presentationDefinition
                    .forwardVelocityMultiplier,
            );

        const lateralVelocity =
            this.randomRange(
                this.definition
                    .lateralVelocityMinimum,
                this.definition
                    .lateralVelocityMaximum,
            ) *
            Math.max(
                0,
                this.presentationDefinition
                    .lateralVelocityMultiplier,
            );

        const windAcceleration =
            this.getLocalWindAcceleration(
                spawnX,
                spawnY,
            );

        const lifetimeMultiplier =
            Math.max(
                0.001,
                role.lifetimeMultiplier *
                this.definition
                    .lifetimeMultiplier,
            );

        const startScaleMultiplier =
            Math.max(
                0,
                role.scaleMultiplier *
                this.definition
                    .startScaleMultiplier,
            );

        const endScaleMultiplier =
            Math.max(
                0,
                role.scaleMultiplier *
                this.definition
                    .endScaleMultiplier,
            );

        const alphaMultiplier =
            Math.max(
                0,
                role.alphaMultiplier *
                this.definition
                    .alphaMultiplier,
            );

        return {
            presentationOrigin:
                "directional",

            x:
                spawnX,

            y:
                spawnY,

            velocityX:
                directionX *
                forwardVelocity +
                perpendicularX *
                lateralVelocity,

            velocityY:
                directionY *
                forwardVelocity +
                perpendicularY *
                lateralVelocity,

            windAccelerationX:
                windAcceleration.x *
                this.presentationDefinition
                    .windAccelerationMultiplier,

            windAccelerationY:
                windAcceleration.y *
                this.presentationDefinition
                    .windAccelerationMultiplier,

            /*
             * Live spatial sampling is essential for a jet that crosses a
             * Fan after leaving the nozzle. Wind is evaluated at the moving
             * particle position rather than frozen at its spawn position.
             */
            sampleWindAccelerationAt:
                (
                    worldX: number,
                    worldY: number,
                ) => {
                    const liveWind =
                        this.localWindSystem
                            .getAccelerationAt(
                                worldX,
                                worldY,
                            );

                    const multiplier =
                        this.presentationDefinition
                            .windAccelerationMultiplier;

                    return {
                        x:
                            liveWind.x *
                            multiplier,
                        y:
                            liveWind.y *
                            multiplier,
                    };
                },

            windInfluenceStartMultiplier:
                this.presentationDefinition
                    .windInfluenceStartMultiplier,

            windInfluenceFullFraction:
                this.presentationDefinition
                    .windInfluenceFullFraction,

            windInfluenceResponseExponent:
                this.presentationDefinition
                    .windInfluenceResponseExponent,

            maximumWindAddedSpeed:
                720,

            orientToVelocity:
                true,

            orientationFollowSpeed:
                this.definition
                    .orientationFollowSpeed,

            angularVelocityRetention:
                this.definition
                    .angularVelocityRetention,

            lifetime:
                this.randomRange(
                    particle
                        .lifetimeMinimum,
                    particle
                        .lifetimeMaximum,
                ) *
                lifetimeMultiplier,

            startScaleX:
                this.randomRange(
                    particle
                        .startScaleXMinimum,
                    particle
                        .startScaleXMaximum,
                ) *
                startScaleMultiplier *
                this.presentationDefinition
                    .startLateralScaleMultiplier,

            startScaleY:
                this.randomRange(
                    particle
                        .startScaleYMinimum,
                    particle
                        .startScaleYMaximum,
                ) *
                startScaleMultiplier *
                this.presentationDefinition
                    .startLongitudinalScaleMultiplier,

            endScaleX:
                this.randomRange(
                    particle
                        .endScaleXMinimum,
                    particle
                        .endScaleXMaximum,
                ) *
                endScaleMultiplier *
                this.presentationDefinition
                    .endLateralScaleMultiplier,

            endScaleY:
                this.randomRange(
                    particle
                        .endScaleYMinimum,
                    particle
                        .endScaleYMaximum,
                ) *
                endScaleMultiplier *
                this.presentationDefinition
                    .endLongitudinalScaleMultiplier,

            maximumAlpha:
                this.clamp01(
                    this.randomRange(
                        particle
                            .alphaMinimum,
                        particle
                            .alphaMaximum,
                    ) *
                    alphaMultiplier,
                ),

            /*
             * Start almost aligned with the source direction. Particle
             * velocity-following then keeps the elongated mask aligned as
             * turbulence or Wind bends the stream.
             */
            rotation:
                sourceDirection +
                Math.PI /
                2 +
                this.randomRange(
                    -0.08,
                    0.08,
                ),

            angularVelocity:
                this.randomRange(
                    particle
                        .angularVelocityMinimum,
                    particle
                        .angularVelocityMaximum,
                ),

            flickerPhase:
                Math.random() *
                Math.PI *
                2,

            flickerSpeed:
                this.randomRange(
                    particle
                        .flickerSpeedMinimum,
                    particle
                        .flickerSpeedMaximum,
                ),

            flickerAmount:
                this.randomRange(
                    particle
                        .flickerAmountMinimum,
                    particle
                        .flickerAmountMaximum,
                ),

            growEndFraction:
                particle
                    .emergenceEndFraction,

            shrinkStartFraction:
                particle
                    .fadeStartFraction,

            turbulenceAmplitude:
                this.randomRange(
                    particle
                        .turbulenceAmplitudeMinimum,
                    particle
                        .turbulenceAmplitudeMaximum,
                ) *
                this.presentationDefinition
                    .turbulenceMultiplier,

            turbulenceFrequency:
                this.randomRange(
                    particle
                        .turbulenceFrequencyMinimum,
                    particle
                        .turbulenceFrequencyMaximum,
                ),

            directionalTerminalFadeStartFraction:
                this.presentationDefinition
                    .terminalFadeStartFraction,

            directionalTerminalFadeEndFraction:
                this.presentationDefinition
                    .terminalFadeEndFraction,

            collisionIgnoredSourceId:
                sourceId,

            collisionResponse: {
                contactInset:
                    this.presentationDefinition
                        .collisionContactInset,
                edgeSlideStrength:
                    this.presentationDefinition
                        .collisionEdgeSlideStrength,
                maximumEdgeTravel:
                    this.presentationDefinition
                        .collisionMaximumEdgeTravel,
                collisionVelocityRetention:
                    this.presentationDefinition
                        .collisionVelocityRetention,
                contactLifetimeSeconds:
                    this.presentationDefinition
                        .collisionContactLifetimeSeconds,
            },

            /*
             * Phase 8F-4 presentation bridge.
             *
             * The resolver is deliberately live rather than capturing one
             * length value at spawn. Existing particles therefore disappear
             * when Water moves the authoritative suppression point closer.
             * When Water moves away, newly emitted particles naturally refill
             * the restored portion of the jet.
             */
            directionalTravelConstraint: {
                originX:
                    sourceOriginX,

                originY:
                    sourceOriginY,

                directionX:
                    sourceDirectionX,

                directionY:
                    sourceDirectionY,

                terminalZoneFraction:
                    this.presentationDefinition
                        .terminalDistanceZoneFraction,

                terminalLongitudinalScaleAtEnd:
                    this.presentationDefinition
                        .terminalLongitudinalScaleAtEnd,

                terminalTurbulenceAtEnd:
                    this.presentationDefinition
                        .terminalTurbulenceAtEnd,

                getMaximumForwardDistance:
                    (): number => {

                        // Simulation, Water suppression and solid-obstacle
                        // suppression share this single authoritative cutoff.
                        // Never allow presentation particles to use the authored
                        // full length after a blocker has shortened the source.
                        return Math.max(
                            0,
                            Math.min(
                                authoredLength,
                                this.fireSourceSystem.getDirectionalEffectiveLength(
                                    sourceId,
                                    authoredLength,
                                ),
                            ),
                        );
                    },
            },

            tint:
                role.tint,
        };
    }

    private getLocalWindAcceleration(
        worldX:
            number,

        worldY:
            number,
    ): {
        readonly x: number;
        readonly y: number;
    } {

        const sampled =
            this.localWindSystem
                .getAccelerationAt(
                    worldX,
                    worldY,
                );

        const sampledX =
            Number.isFinite(
                sampled.x,
            )
                ? sampled.x
                : 0;

        const sampledY =
            Number.isFinite(
                sampled.y,
            )
                ? sampled.y
                : 0;

        let accelerationX =
            sampledX *
            Math.max(
                0,
                this.definition
                    .localWindAccelerationMultiplier,
            );

        let accelerationY =
            sampledY *
            Math.max(
                0,
                this.definition
                    .localWindAccelerationMultiplier,
            );

        const magnitude =
            Math.sqrt(
                accelerationX *
                accelerationX +
                accelerationY *
                accelerationY,
            );

        const maximumMagnitude =
            Math.max(
                0,
                this.definition
                    .maximumLocalWindAcceleration,
            );

        if (
            maximumMagnitude > 0 &&
            magnitude >
            maximumMagnitude
        ) {
            const scale =
                maximumMagnitude /
                magnitude;

            accelerationX *=
                scale;

            accelerationY *=
                scale;
        }

        return {
            x:
                accelerationX,

            y:
                accelerationY,
        };
    }

    private selectMaterialLayer():
        FireParticleMaterialLayer {

        return (
            Math.random() <
                this.clamp01(
                    this.particleDefinition
                        .material
                        .detailParticleChance,
                )
                ? "detail"
                : "main"
        );
    }

    private selectThermalRole():
        FireParticleThermalRoleDefinition {

        const hot =
            this.particleDefinition
                .thermalRoles
                .hot;

        const body =
            this.particleDefinition
                .thermalRoles
                .body;

        const cool =
            this.particleDefinition
                .thermalRoles
                .cool;

        /*
         * Jet-specific weighting keeps the nozzle visibly hotter while still
         * using the exact same authored thermal materials.
         */
        const hotWeight =
            Math.max(
                0,
                hot.weight *
                this.presentationDefinition
                    .hotWeightMultiplier,
            );

        const bodyWeight =
            Math.max(
                0,
                body.weight *
                this.presentationDefinition
                    .bodyWeightMultiplier,
            );

        const coolWeight =
            Math.max(
                0,
                cool.weight *
                this.presentationDefinition
                    .coolWeightMultiplier,
            );

        const totalWeight =
            hotWeight +
            bodyWeight +
            coolWeight;

        if (
            totalWeight <=
            0
        ) {
            return body;
        }

        const roll =
            Math.random() *
            totalWeight;

        if (
            roll <
            hotWeight
        ) {
            return hot;
        }

        if (
            roll <
            hotWeight +
            bodyWeight
        ) {
            return body;
        }

        return cool;
    }

    private getOrCreateEmitterState(
        source:
            FireSource,
    ): JetFireEmitterState {

        const existing =
            this.emitterStates
                .get(
                    source,
                );

        if (existing) {
            return existing;
        }

        if (
            this.emitterStates.size >=
            Math.max(
                1,
                this.definition
                    .emitterState
                    .maximumTrackedStates,
            )
        ) {
            this.removeOldestEmitterState();
        }

        const state:
            JetFireEmitterState = {
            fractionalCarry:
                0,

            lastSeenUpdate:
                this.updateSerial,
        };

        this.emitterStates.set(
            source,
            state,
        );

        return state;
    }

    private cleanupInactiveEmitterStates():
        void {

        this.emitterStates.forEach(
            (
                state,
                source,
            ): void => {

                if (
                    state.lastSeenUpdate !==
                    this.updateSerial
                ) {
                    this.emitterStates.delete(
                        source,
                    );
                }
            },
        );
    }

    private removeOldestEmitterState():
        void {

        let oldestSource:
            FireSource | null =
            null;

        let oldestUpdate =
            Number.POSITIVE_INFINITY;

        this.emitterStates.forEach(
            (
                state,
                source,
            ): void => {

                if (
                    state.lastSeenUpdate <
                    oldestUpdate
                ) {
                    oldestUpdate =
                        state.lastSeenUpdate;

                    oldestSource =
                        source;
                }
            },
        );

        if (oldestSource) {
            this.emitterStates.delete(
                oldestSource,
            );
        }
    }

    private randomRange(
        minimum:
            number,

        maximum:
            number,
    ): number {

        if (
            maximum <=
            minimum
        ) {
            return minimum;
        }

        return (
            minimum +
            Math.random() *
            (
                maximum -
                minimum
            )
        );
    }

    private clamp01(
        value:
            number,
    ): number {

        return Math.max(
            0,
            Math.min(
                1,
                value,
            ),
        );
    }
}
