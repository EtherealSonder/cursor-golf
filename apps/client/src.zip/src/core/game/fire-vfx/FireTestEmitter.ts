import type {
    FireParticleMaterialLayer,
    FireParticleThermalRoleDefinition,
    FireParticleVfxDefinition,
} from "../config/FireParticleVfxDefinition";

import type {
    FireVfxParticleActivation,
} from "./FireVfxParticle";

import type {
    FireVfxTextureVariant,
} from "./FireVfxSystem";

export type FireTestEmitterSpawnCallback =
    (
        variant:
            FireVfxTextureVariant,

        materialLayer:
            FireParticleMaterialLayer,

        activation:
            FireVfxParticleActivation,
    ) => boolean;

/**
 * FIRE-VFX-2B isolated Fire test emitter.
 *
 * The emitter still owns only presentation spawn timing and particle
 * activation parameters.
 *
 * It has no FireManager, FireCell, Wind, surface, heat or gameplay
 * responsibility.
 *
 * Hybrid material rule:
 *
 * most spawns -> original FIRE-VFX-1 soft material
 * minority     -> FIRE-VFX-2B irregular detail material
 */
export class FireTestEmitter {

    private spawnAccumulator =
        0;

    public constructor(
        private readonly definition:
            FireParticleVfxDefinition,

        private readonly spawnParticle:
            FireTestEmitterSpawnCallback,
    ) {
    }

    public update(
        deltaTime:
            number,
    ): void {

        if (
            !this.definition.enabled ||
            !Number.isFinite(
                deltaTime,
            ) ||
            deltaTime <=
            0
        ) {
            return;
        }

        const particlesPerSecond =
            Math.max(
                0,
                this.definition
                    .testEmitter
                    .particlesPerSecond,
            );

        if (
            particlesPerSecond <=
            0
        ) {
            return;
        }

        this.spawnAccumulator +=
            deltaTime *
            particlesPerSecond;

        /*
         * Consume the fractional emission budget without allocating arrays
         * or per-frame temporary emitter state.
         */
        while (
            this.spawnAccumulator >=
            1
        ) {
            this.spawnAccumulator -=
                1;

            this.spawnOne();
        }
    }

    public reset():
        void {

        this.spawnAccumulator =
            0;
    }

    public destroy():
        void {

        this.reset();
    }

    private spawnOne():
        void {

        const thermalRole =
            this.selectThermalRole();

        const materialLayer =
            this.selectMaterialLayer();

        const activation =
            this.createActivation(
                thermalRole,
            );

        this.spawnParticle(
            thermalRole.textureVariant,
            materialLayer,
            activation,
        );
    }

    private selectMaterialLayer():
        FireParticleMaterialLayer {

        const detailChance =
            this.clamp01(
                this.definition
                    .material
                    .detailParticleChance,
            );

        return (
            Math.random() <
                detailChance
                ? "detail"
                : "main"
        );
    }

    private selectThermalRole():
        FireParticleThermalRoleDefinition {

        const hot =
            this.definition
                .thermalRoles
                .hot;

        const body =
            this.definition
                .thermalRoles
                .body;

        const cool =
            this.definition
                .thermalRoles
                .cool;

        const hotWeight =
            Math.max(
                0,
                hot.weight,
            );

        const bodyWeight =
            Math.max(
                0,
                body.weight,
            );

        const coolWeight =
            Math.max(
                0,
                cool.weight,
            );

        const totalWeight =
            hotWeight +
            bodyWeight +
            coolWeight;

        if (
            totalWeight <=
            0
        ) {
            return body;
        }

        const roll =
            Math.random() *
            totalWeight;

        if (
            roll <
            hotWeight
        ) {
            return hot;
        }

        if (
            roll <
            hotWeight +
            bodyWeight
        ) {
            return body;
        }

        return cool;
    }

    private createActivation(
        role:
            FireParticleThermalRoleDefinition,
    ): FireVfxParticleActivation {

        const emitter =
            this.definition
                .testEmitter;

        const particle =
            this.definition
                .particle;

        const angle =
            Math.random() *
            Math.PI *
            2;

        /*
         * sqrt(random) gives a uniform distribution over the ellipse area
         * rather than concentrating particles in the center.
         */
        const radius =
            Math.sqrt(
                Math.random(),
            );

        const spawnOffsetX =
            Math.cos(
                angle,
            ) *
            emitter.spawnRadiusX *
            radius;

        const spawnOffsetY =
            Math.sin(
                angle,
            ) *
            emitter.spawnRadiusY *
            radius;

        const speedMultiplier =
            Math.max(
                0,
                role.speedMultiplier,
            );

        const scaleMultiplier =
            Math.max(
                0,
                role.scaleMultiplier,
            );

        const lifetimeMultiplier =
            Math.max(
                0.001,
                role.lifetimeMultiplier,
            );

        const alphaMultiplier =
            Math.max(
                0,
                role.alphaMultiplier,
            );

        return {
            x:
                emitter.positionX +
                spawnOffsetX,

            y:
                emitter.positionY +
                spawnOffsetY,

            velocityX:
                this.randomRange(
                    particle
                        .horizontalVelocityMinimum,
                    particle
                        .horizontalVelocityMaximum,
                ) *
                speedMultiplier,

            velocityY:
                this.randomRange(
                    particle
                        .upwardVelocityMinimum,
                    particle
                        .upwardVelocityMaximum,
                ) *
                speedMultiplier,

            lifetime:
                this.randomRange(
                    particle
                        .lifetimeMinimum,
                    particle
                        .lifetimeMaximum,
                ) *
                lifetimeMultiplier,

            startScaleX:
                this.randomRange(
                    particle
                        .startScaleXMinimum,
                    particle
                        .startScaleXMaximum,
                ) *
                scaleMultiplier,

            startScaleY:
                this.randomRange(
                    particle
                        .startScaleYMinimum,
                    particle
                        .startScaleYMaximum,
                ) *
                scaleMultiplier,

            endScaleX:
                this.randomRange(
                    particle
                        .endScaleXMinimum,
                    particle
                        .endScaleXMaximum,
                ) *
                scaleMultiplier,

            endScaleY:
                this.randomRange(
                    particle
                        .endScaleYMinimum,
                    particle
                        .endScaleYMaximum,
                ) *
                scaleMultiplier,

            maximumAlpha:
                this.clamp01(
                    this.randomRange(
                        particle
                            .alphaMinimum,
                        particle
                            .alphaMaximum,
                    ) *
                    alphaMultiplier,
                ),

            rotation:
                this.randomRange(
                    particle
                        .rotationMinimum,
                    particle
                        .rotationMaximum,
                ),

            angularVelocity:
                this.randomRange(
                    particle
                        .angularVelocityMinimum,
                    particle
                        .angularVelocityMaximum,
                ),

            flickerPhase:
                Math.random() *
                Math.PI *
                2,

            flickerSpeed:
                this.randomRange(
                    particle
                        .flickerSpeedMinimum,
                    particle
                        .flickerSpeedMaximum,
                ),

            flickerAmount:
                this.randomRange(
                    particle
                        .flickerAmountMinimum,
                    particle
                        .flickerAmountMaximum,
                ),

            growEndFraction:
                particle
                    .emergenceEndFraction,

            shrinkStartFraction:
                particle
                    .fadeStartFraction,

            turbulenceAmplitude:
                this.randomRange(
                    particle
                        .turbulenceAmplitudeMinimum,
                    particle
                        .turbulenceAmplitudeMaximum,
                ),

            turbulenceFrequency:
                this.randomRange(
                    particle
                        .turbulenceFrequencyMinimum,
                    particle
                        .turbulenceFrequencyMaximum,
                ),

            tint:
                role.tint,
        };
    }

    private randomRange(
        minimum:
            number,

        maximum:
            number,
    ): number {

        if (
            maximum <=
            minimum
        ) {
            return minimum;
        }

        return (
            minimum +
            Math.random() *
            (
                maximum -
                minimum
            )
        );
    }

    private clamp01(
        value:
            number,
    ): number {

        return Math.max(
            0,
            Math.min(
                1,
                value,
            ),
        );
    }
}
