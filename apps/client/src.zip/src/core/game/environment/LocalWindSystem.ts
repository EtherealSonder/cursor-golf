import type {
    LocalWindSourceDefinition,
} from "../config/LocalWindDefinition";

import type { LocalWindObstacleQuery } from "./LocalWindObstacleQuery";

import {
    DEFAULT_LOCAL_WIND_SOURCE_DEFINITIONS,
} from "../config/LocalWindDefinition";


interface MutableLocalWindSourceDefinition {
    id: string;
    positionX: number;
    positionY: number;
    directionRadians: number;
    range: number;
    startHalfWidth: number;
    endHalfWidth: number;
    acceleration: number;
    endStrengthMultiplier: number;
    edgeFalloffFraction: number;
    flowMode?: "push" | "pull";
    enabled: boolean;
}

export interface LocalWindVector {
    readonly x: number;
    readonly y: number;
}

export interface LocalWindSample {
    readonly acceleration: LocalWindVector;
    readonly contributingSourceIds: readonly string[];
}

/**
 * Authoritative query service for spatial directional
 * airflow.
 *
 * The system owns no rendering and no Ball state.
 * Consumers ask for the acceleration at a world-space
 * point. Overlapping sources are combined by vector
 * addition.
 */
export interface LocalWindImpactAwareTarget {
    readonly id: string;
    readonly radius: number;
    readonly getX: () => number;
    readonly getY: () => number;
    readonly notifyImpact: (positionX: number, positionY: number, sourceId: string) => void;
}

export class LocalWindSystem {
    private obstacleQuery: LocalWindObstacleQuery | null = null;

    public setObstacleQuery(query: LocalWindObstacleQuery | null): void {
        this.obstacleQuery = query;
        this.sampleCache.clear();
    }

    public getObstacleQuery(): LocalWindObstacleQuery | null {
        return this.obstacleQuery;
    }

    private performanceQueryCount = 0;
    private performanceQueryMilliseconds = 0;
    private performanceCacheHits = 0;
    private performanceCacheMisses = 0;
    private readonly sampleCache = new Map<string, LocalWindSample>();
    private readonly sampleCacheCellSize = 4;
    private readonly impactAwareTargets = new Map<string, LocalWindImpactAwareTarget>();
    private readonly activeImpactSourcesByTarget = new Map<string, Set<string>>();

    public registerImpactAwareTarget(target: LocalWindImpactAwareTarget): void {
        this.impactAwareTargets.set(target.id, target);
    }

    public unregisterImpactAwareTarget(id: string): void {
        this.impactAwareTargets.delete(id);
        this.activeImpactSourcesByTarget.delete(id);
    }

    /** Edge-triggered authoritative Wind contact for AI awareness. */
    public updateImpactAwareTargets(): void {
        for (const target of this.impactAwareTargets.values()) {
            const sample = this.sampleAt(target.getX(), target.getY());
            const current = new Set(sample.contributingSourceIds);
            const previous = this.activeImpactSourcesByTarget.get(target.id) ?? new Set<string>();
            for (const sourceId of current) {
                if (previous.has(sourceId)) continue;
                const magnitude = Math.hypot(sample.acceleration.x, sample.acceleration.y);
                const nx = magnitude > 0 ? sample.acceleration.x / magnitude : 1;
                const ny = magnitude > 0 ? sample.acceleration.y / magnitude : 0;
                target.notifyImpact(
                    target.getX() - nx * target.radius,
                    target.getY() - ny * target.radius,
                    sourceId,
                );
            }
            this.activeImpactSourcesByTarget.set(target.id, current);
        }
    }

    public beginPerformanceFrame(): void {
        this.performanceQueryCount = 0;
        this.performanceQueryMilliseconds = 0;
        this.performanceCacheHits = 0;
        this.performanceCacheMisses = 0;
        this.sampleCache.clear();
    }

    public getPerformanceDetails() {
        return {
            queryCount: this.performanceQueryCount,
            queryMilliseconds: this.performanceQueryMilliseconds,
            cacheHits: this.performanceCacheHits,
            cacheMisses: this.performanceCacheMisses,
        };
    }


    private sources:
        MutableLocalWindSourceDefinition[];

    constructor(
        sources:
            readonly LocalWindSourceDefinition[] =
            DEFAULT_LOCAL_WIND_SOURCE_DEFINITIONS,
    ) {
        this.validateSources(
            sources,
        );

        this.sources =
            sources.map(
                (
                    source,
                ) => ({
                    ...source,
                }),
            );
    }

    public getSources():
        readonly LocalWindSourceDefinition[] {

        return this.sources;
    }

    public replaceSources(
        sources:
            readonly LocalWindSourceDefinition[],
    ): void {

        this.validateSources(sources);

        this.sources =
            sources.map(
                (source) => ({
                    ...source,
                }),
            );
    }



    public addSource(source: LocalWindSourceDefinition): void {
        this.validateSources([...this.sources, source]);
        this.sources.push({ ...source });
        this.sampleCache.clear();
    }

    public removeSource(sourceId: string): boolean {
        const index = this.sources.findIndex((source) => source.id === sourceId);
        if (index < 0) return false;
        this.sources.splice(index, 1);
        this.sampleCache.clear();
        return true;
    }

    public setSourceEnabled(sourceId: string, enabled: boolean): boolean {
        const source = this.sources.find((candidate) => candidate.id === sourceId);
        if (!source) return false;
        source.enabled = enabled;
        this.sampleCache.clear();
        return true;
    }

    /**
     * Updates only the runtime transform of one source.
     *
     * This is used by physical mechanisms such as Fan. The airflow
     * shape and strength configuration remain unchanged. Source objects
     * are updated in place so presentation systems holding a reference
     * to the source observe the new transform without rebuilding the
     * complete source collection.
     */
    public updateSourceTransform(
        sourceId: string,
        positionX: number,
        positionY: number,
        directionRadians: number,
    ): boolean {

        if (
            sourceId.trim().length === 0 ||
            ![
                positionX,
                positionY,
                directionRadians,
            ].every(Number.isFinite)
        ) {
            return false;
        }

        const source =
            this.sources.find(
                (candidate) =>
                    candidate.id === sourceId,
            );

        if (!source) {
            return false;
        }

        source.positionX = positionX;
        source.positionY = positionY;
        source.directionRadians = directionRadians;
        this.sampleCache.clear();

        return true;
    }

    public getAccelerationAt(
        worldX: number,
        worldY: number,
    ): LocalWindVector {

        return this.sampleAt(
            worldX,
            worldY,
        ).acceleration;
    }

    public sampleAt(
        worldX: number,
        worldY: number,
    ): LocalWindSample {

        const performanceStartedAt =
            performance.now();
        this.performanceQueryCount += 1;

        if (
            !Number.isFinite(
                worldX,
            ) ||
            !Number.isFinite(
                worldY,
            )
        ) {
            this.performanceQueryMilliseconds +=
                performance.now() -
                performanceStartedAt;
            return {
                acceleration: {
                    x: 0,
                    y: 0,
                },
                contributingSourceIds: [],
            };
        }

        const cacheX = Math.round(worldX / this.sampleCacheCellSize);
        const cacheY = Math.round(worldY / this.sampleCacheCellSize);
        const cacheKey = `${cacheX}:${cacheY}`;
        const cached = this.sampleCache.get(cacheKey);

        if (cached) {
            this.performanceCacheHits += 1;
            this.performanceQueryMilliseconds += performance.now() - performanceStartedAt;
            return cached;
        }

        this.performanceCacheMisses += 1;

        let accelerationX = 0;
        let accelerationY = 0;

        const contributingSourceIds:
            string[] = [];

        for (
            const source
            of this.sources
        ) {
            const sourceAcceleration =
                this.getSourceAccelerationAt(
                    source,
                    worldX,
                    worldY,
                );

            if (
                sourceAcceleration.x === 0 &&
                sourceAcceleration.y === 0
            ) {
                continue;
            }

            accelerationX +=
                sourceAcceleration.x;

            accelerationY +=
                sourceAcceleration.y;

            contributingSourceIds.push(
                source.id,
            );
        }

        const sample: LocalWindSample = {
            acceleration: {
                x: accelerationX,
                y: accelerationY,
            },
            contributingSourceIds,
        };

        this.sampleCache.set(cacheKey, sample);
        this.performanceQueryMilliseconds += performance.now() - performanceStartedAt;
        return sample;
    }

    public containsPoint(
        source:
            LocalWindSourceDefinition,

        worldX: number,
        worldY: number,
    ): boolean {

        return (
            this.calculateSourceInfluence(
                source,
                worldX,
                worldY,
            ) >
            0
        );
    }

    private getSourceAccelerationAt(
        source:
            LocalWindSourceDefinition,

        worldX: number,
        worldY: number,
    ): LocalWindVector {

        const influence =
            this.calculateSourceInfluence(
                source,
                worldX,
                worldY,
            );

        if (
            influence <=
            0
        ) {
            return {
                x: 0,
                y: 0,
            };
        }

        const directionX =
            Math.cos(
                source.directionRadians,
            );

        const directionY =
            Math.sin(
                source.directionRadians,
            );

        /*
         * Static geometry is a hard Local Wind occluder. There is deliberately
         * no edge wrapping or redirected airflow: if the straight source-to-
         * sample path intersects a static blocker, this source contributes no
         * Wind at the sample point.
         */
        if (this.obstacleQuery?.segmentBlocked(
            source.positionX,
            source.positionY,
            worldX,
            worldY,
        )) {
            return { x: 0, y: 0 };
        }

        const accelerationMagnitude =
            source.acceleration *
            influence;
        const flowSign = source.flowMode === "pull" ? -1 : 1;

        return {
            x: directionX * accelerationMagnitude * flowSign,
            y: directionY * accelerationMagnitude * flowSign,
        };
    }

    /**
     * Returns a normalized source influence.
     *
     * 0 = outside/no influence
     * 1 = full source-centre influence
     *
     * The region is a widening trapezoid in source
     * local space. Strength falls gradually with
     * distance and near the lateral edges.
     */
    private calculateSourceInfluence(
        source:
            LocalWindSourceDefinition,

        worldX: number,
        worldY: number,
    ): number {

        if (
            !source.enabled
        ) {
            return 0;
        }

        const directionX =
            Math.cos(
                source.directionRadians,
            );

        const directionY =
            Math.sin(
                source.directionRadians,
            );

        const perpendicularX =
            -directionY;

        const perpendicularY =
            directionX;

        const offsetX =
            worldX -
            source.positionX;

        const offsetY =
            worldY -
            source.positionY;

        const longitudinalDistance =
            offsetX *
            directionX +
            offsetY *
            directionY;

        if (
            longitudinalDistance <
            0 ||
            longitudinalDistance >
            source.range
        ) {
            return 0;
        }

        const rangeProgress =
            source.range >
                0
                ? longitudinalDistance /
                source.range
                : 0;

        const currentHalfWidth =
            this.lerp(
                source.startHalfWidth,
                source.endHalfWidth,
                rangeProgress,
            );

        const lateralDistance =
            Math.abs(
                offsetX *
                perpendicularX +
                offsetY *
                perpendicularY,
            );

        if (
            lateralDistance >
            currentHalfWidth
        ) {
            return 0;
        }

        const longitudinalMultiplier =
            this.lerp(
                1,
                source.endStrengthMultiplier,
                rangeProgress,
            );

        const edgeFalloffWidth =
            currentHalfWidth *
            source.edgeFalloffFraction;

        let lateralMultiplier =
            1;

        if (
            edgeFalloffWidth >
            0
        ) {
            const fullStrengthHalfWidth =
                currentHalfWidth -
                edgeFalloffWidth;

            if (
                lateralDistance >
                fullStrengthHalfWidth
            ) {
                lateralMultiplier =
                    1 -
                    (
                        lateralDistance -
                        fullStrengthHalfWidth
                    ) /
                    edgeFalloffWidth;
            }
        }

        return Math.min(
            1,
            Math.max(
                0,
                longitudinalMultiplier *
                lateralMultiplier,
            ),
        );
    }

    private lerp(
        start: number,
        end: number,
        amount: number,
    ): number {

        return (
            start +
            (
                end -
                start
            ) *
            Math.min(
                Math.max(
                    amount,
                    0,
                ),
                1,
            )
        );
    }

    private validateSources(
        sources:
            readonly LocalWindSourceDefinition[],
    ): void {

        const ids =
            new Set<string>();

        for (
            const source
            of sources
        ) {
            if (
                source.id.trim()
                    .length ===
                0
            ) {
                throw new Error(
                    "Local wind source id cannot be empty.",
                );
            }

            if (
                ids.has(
                    source.id,
                )
            ) {
                throw new Error(
                    `Duplicate local wind source id '${source.id}'.`,
                );
            }

            ids.add(
                source.id,
            );

            const finiteValues = [
                source.positionX,
                source.positionY,
                source.directionRadians,
                source.range,
                source.startHalfWidth,
                source.endHalfWidth,
                source.acceleration,
                source.endStrengthMultiplier,
                source.edgeFalloffFraction,
            ];

            if (
                !finiteValues.every(
                    Number.isFinite,
                )
            ) {
                throw new Error(
                    `Local wind source '${source.id}' contains a non-finite value.`,
                );
            }

            if (
                source.range <=
                0 ||
                source.startHalfWidth <=
                0 ||
                source.endHalfWidth <=
                0
            ) {
                throw new Error(
                    `Local wind source '${source.id}' requires positive range and widths.`,
                );
            }

            if (
                source.acceleration <
                0
            ) {
                throw new Error(
                    `Local wind source '${source.id}' acceleration cannot be negative.`,
                );
            }

            if (
                source.endStrengthMultiplier <
                0 ||
                source.endStrengthMultiplier >
                1
            ) {
                throw new Error(
                    `Local wind source '${source.id}' endStrengthMultiplier must remain between 0 and 1.`,
                );
            }

            if (
                source.edgeFalloffFraction <
                0 ||
                source.edgeFalloffFraction >
                1
            ) {
                throw new Error(
                    `Local wind source '${source.id}' edgeFalloffFraction must remain between 0 and 1.`,
                );
            }
        }
    }
}
