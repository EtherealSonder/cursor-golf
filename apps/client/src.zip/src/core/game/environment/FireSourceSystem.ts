import type {
    FireSourceDefinition,
} from "../config/FireSourceDefinition";

import {
    FireSourceType,
    validateFireSourceDefinition,
} from "../config/FireSourceDefinition";

import type {
    EnvironmentField,
} from "./EnvironmentField";

import {
    FireSource,
} from "./FireSource";

import {
    DEFAULT_DIRECTIONAL_FIRE_SOURCE_DEFINITION,
} from "../config/DirectionalFireSourceDefinition";

/**
 * Authoritative collection and lifecycle owner for gameplay Fire sources.
 *
 * 4B-6A establishes identity, mutation, lifecycle and World integration.
 * Source-specific heat deposition is added in 4B-6B and 4B-6C.
 */
export class FireSourceSystem {
    private readonly sources: FireSource[] = [];

    private readonly sourceById =
        new Map<string, FireSource>();

    /**
     * Phase 8F-4/8F-5 transient directional-jet cutoff distances for the current
     * frame. Airborne and standing Water both contribute to this shared map.
     * The earliest current Water contact wins without disabling the source.
     */
    private readonly directionalSuppressionDistanceBySourceId =
        new Map<string, number>();

    /** Current-frame solid-obstacle cutoff. Kept separate from Water so both
     * authorities can contribute and the earliest contact always wins. */
    private readonly directionalObstacleDistanceBySourceId =
        new Map<string, number>();

    constructor(
        private readonly environmentField: EnvironmentField,
    ) { }

    public update(deltaTime: number): void {
        if (!Number.isFinite(deltaTime) || deltaTime <= 0) {
            return;
        }

        for (const source of this.sources) {
            source.update(deltaTime);

            if (!source.isEnabled()) {
                continue;
            }

            const definition =
                source.getDefinition();

            switch (definition.type) {
                case FireSourceType.Point:
                    this.updatePointSource(
                        source,
                        definition.radius,
                        definition.heatAmount,
                    );
                    break;

                case FireSourceType.Persistent:
                    this.environmentField.depositHeat(
                        source.getPositionX(),
                        source.getPositionY(),
                        definition.radius,
                        definition.heatPerSecond *
                        deltaTime,
                    );
                    break;

                case FireSourceType.Directional:
                    this.updateDirectionalSource(
                        source,
                        definition.length,
                        definition.heatPerSecond,
                        definition.endHeatMultiplier,
                        deltaTime,
                    );
                    break;
            }
        }
    }

    private updateDirectionalSource(
        source: FireSource,
        length: number,
        heatPerSecond: number,
        endHeatMultiplier: number,
        deltaTime: number,
    ): void {
        const tuning =
            DEFAULT_DIRECTIONAL_FIRE_SOURCE_DEFINITION;

        const effectiveLength =
            Math.min(
                length,
                this.getDirectionalEffectiveLength(
                    source.getId(),
                    length,
                ),
            );

        if (effectiveLength <= 0) {
            return;
        }

        const spacing =
            Math.max(
                1,
                tuning.sampleSpacing,
            );

        const sampleCount =
            Math.max(
                1,
                Math.ceil(
                    effectiveLength /
                    spacing,
                ),
            );

        const direction =
            source.getDirectionRadians();

        const directionX =
            Math.cos(direction);

        const directionY =
            Math.sin(direction);

        /*
         * Model the jet as heat density along a stream rather than one
         * fixed heat budget divided across the whole length.
         *
         * Spacing normalization keeps heat per unit length approximately
         * stable if sample density is tuned later.
         */
        const spacingDensityScale =
            spacing /
            Math.max(
                1,
                tuning.heatDensityReferenceSpacing,
            );

        const baseHeatPerSample =
            heatPerSecond *
            deltaTime *
            spacingDensityScale;

        for (
            let sampleIndex = 0;
            sampleIndex <= sampleCount;
            sampleIndex += 1
        ) {
            const normalizedDistance =
                sampleIndex /
                sampleCount;

            const distance =
                normalizedDistance *
                effectiveLength;

            const heatMultiplier =
                1 +
                (
                    endHeatMultiplier -
                    1
                ) *
                normalizedDistance;

            const sampleX =
                source.getPositionX() +
                directionX *
                distance;

            const sampleY =
                source.getPositionY() +
                directionY *
                distance;

            this.environmentField.depositHeat(
                sampleX,
                sampleY,
                tuning.sampleRadius,
                baseHeatPerSample *
                heatMultiplier,
            );
        }
    }

    private updatePointSource(
        source: FireSource,
        radius: number,
        heatAmount: number,
    ): void {
        if (
            source.hasConsumedPointEmission()
        ) {
            return;
        }

        this.environmentField.depositHeat(
            source.getPositionX(),
            source.getPositionY(),
            radius,
            heatAmount,
        );

        source.markPointEmissionConsumed();
    }


    /**
     * Clears all transient directional Water suppression before current-frame
     * airborne and standing Water contacts are evaluated. This makes direct
     * Water suppression transient by design.
     */
    public beginDirectionalWaterSuppressionFrame(): void {
        this.directionalSuppressionDistanceBySourceId.clear();
    }

    /** Clears transient solid-obstacle cutoffs before current-frame queries. */
    public beginDirectionalObstacleSuppressionFrame(): void {
        this.directionalObstacleDistanceBySourceId.clear();
    }

    /** Records the nearest solid obstacle reached by one directional source. */
    public suppressDirectionalSourceFromObstacleDistance(
        sourceId: string,
        distanceFromSource: number,
    ): boolean {
        const source = this.sourceById.get(sourceId);
        if (!source || source.getType() !== FireSourceType.Directional || !Number.isFinite(distanceFromSource)) {
            return false;
        }
        const definition = source.getDefinition();
        if (definition.type !== FireSourceType.Directional) return false;
        const clampedDistance = Math.max(0, Math.min(definition.length, distanceFromSource));
        const previous = this.directionalObstacleDistanceBySourceId.get(sourceId);
        if (previous === undefined || clampedDistance < previous) {
            this.directionalObstacleDistanceBySourceId.set(sourceId, clampedDistance);
        }
        return true;
    }

    /**
     * Applies a current-frame cutoff to one enabled directional source. The
     * source remains enabled and operational. Multiple Water contacts keep the
     * earliest contact point along the jet.
     */
    public suppressDirectionalSourceFromDistance(
        sourceId: string,
        distanceFromSource: number,
    ): boolean {
        const source =
            this.sourceById.get(sourceId);

        if (
            !source ||
            source.getType() !== FireSourceType.Directional ||
            !Number.isFinite(distanceFromSource)
        ) {
            return false;
        }

        const definition =
            source.getDefinition();

        if (definition.type !== FireSourceType.Directional) {
            return false;
        }

        const clampedDistance =
            Math.max(
                0,
                Math.min(
                    definition.length,
                    distanceFromSource,
                ),
            );

        const previousDistance =
            this.directionalSuppressionDistanceBySourceId
                .get(sourceId);

        if (
            previousDistance === undefined ||
            clampedDistance < previousDistance
        ) {
            this.directionalSuppressionDistanceBySourceId.set(
                sourceId,
                clampedDistance,
            );
        }

        return true;
    }

    public getDirectionalEffectiveLength(
        sourceId: string,
        authoredLength?: number,
    ): number {
        const source =
            this.sourceById.get(sourceId);

        if (!source) {
            return 0;
        }

        const definition =
            source.getDefinition();

        if (definition.type !== FireSourceType.Directional) {
            return 0;
        }

        const fullLength =
            authoredLength ??
            definition.length;

        return Math.min(
            fullLength,
            this.directionalSuppressionDistanceBySourceId.get(sourceId) ?? fullLength,
            this.directionalObstacleDistanceBySourceId.get(sourceId) ?? fullLength,
        );
    }

    public isDirectionalSourceWaterSuppressed(
        sourceId: string,
    ): boolean {
        return this.directionalSuppressionDistanceBySourceId
            .has(sourceId);
    }

    public addSource(
        definition: FireSourceDefinition,
    ): FireSource {
        validateFireSourceDefinition(definition);

        if (this.sourceById.has(definition.id)) {
            throw new Error(
                `Fire source "${definition.id}" already exists.`,
            );
        }

        const source =
            new FireSource(definition);

        this.sources.push(source);
        this.sourceById.set(
            definition.id,
            source,
        );

        return source;
    }

    public removeSource(
        sourceId: string,
    ): boolean {
        const source =
            this.sourceById.get(sourceId);

        if (!source) {
            return false;
        }

        this.sourceById.delete(sourceId);

        const index =
            this.sources.indexOf(source);

        if (index >= 0) {
            this.sources.splice(index, 1);
        }

        return true;
    }

    public clearSources(): void {
        this.sources.length = 0;
        this.sourceById.clear();
        this.directionalSuppressionDistanceBySourceId.clear();
    }

    public setSourceDirection(
        sourceId: string,
        directionRadians: number,
    ): boolean {
        const source = this.sourceById.get(sourceId);
        if (!source) return false;
        source.setDirectionRadians(directionRadians);
        return true;
    }

    public setSourcePosition(
        sourceId: string,
        x: number,
        y: number,
    ): boolean {
        const source = this.sourceById.get(sourceId);
        if (!source) return false;
        source.setPosition(x, y);
        return true;
    }

    public setSourceEnabled(
        sourceId: string,
        enabled: boolean,
    ): boolean {
        const source =
            this.sourceById.get(sourceId);

        if (!source) {
            return false;
        }

        source.setEnabled(enabled);
        return true;
    }

    public getSourceById(
        sourceId: string,
    ): FireSource | null {
        return this.sourceById.get(sourceId) ?? null;
    }

    public getSources():
        readonly FireSource[] {
        return this.sources;
    }

    public getActiveSourceCount():
        number {
        let count = 0;

        for (const source of this.sources) {
            if (source.isEnabled()) {
                count += 1;
            }
        }

        return count;
    }

    public reset(): void {
        this.directionalSuppressionDistanceBySourceId.clear();

        for (const source of this.sources) {
            source.resetRuntimeState();
        }
    }
}
